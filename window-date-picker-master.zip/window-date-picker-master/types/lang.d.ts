export interface Lang {
    DAYS_ABBR: String[];
    MONTHS: String[];
    MONTHS_ABBR: String[];
    AM_PM: String[];
    BUTTONS: String[];
    INVALID_DATE: String;
}